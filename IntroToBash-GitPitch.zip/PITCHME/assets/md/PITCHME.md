## Intro to BASH Shell Scripting
### John Kennedy
#### skebi69@gmail.com
Presentation: https://gitpitch.com/skebi69/IntroBash
Source: https://github.com/skebi69/IntroBash

---
### Disclaimer
-   As in most of Linux, there is more than one way to do things. My way may not always be the best.  <!-- .element: class="fragment" -->
-   Some of my techniques and methods may be older/outdated. I am old.  <!-- .element: class="fragment" -->
-   There are going to be somethings that I miss out on (arrays) either on purpose or by accident.  <!-- .element: class="fragment" -->

+++
### Notes
-   I would like to have built a usable script but did not have time so:  <!-- .element: class="fragment" -->
-   Hopefully my examples will be easily modified to fit your needs  <!-- .element: class="fragment" -->

---
### Topics
-   Why script?  <!-- .element: class="fragment" -->
-   She-Bang - Not Ricky Martin (see - I told you I was old)  <!-- .element: class="fragment" -->
-   Variables  <!-- .element: class="fragment" -->
-   Special variables  <!-- .element: class="fragment" -->
-   User input  <!-- .element: class="fragment" -->

+++
### Topics (Cont)
-   Conditional handling  <!-- .element: class="fragment" -->
-   Select/case text menu  <!-- .element: class="fragment" -->
-   Loops  <!-- .element: class="fragment" -->
-   Functions  <!-- .element: class="fragment" -->

---
### Why Script?
-   Run series of commands  <!-- .element: class="fragment" -->
-   Build a long, complicated command  <!-- .element: class="fragment" -->
-   Run commands that depend on specific conditions/results  <!-- .element: class="fragment" -->
-   Run repetitive commands  <!-- .element: class="fragment" -->
-   A lazy sysadmin is a good sysadmin - Let your scripts do the work for you  <!-- .element: class="fragment" -->

---
### She bang (#!)
-   Start every script to set interpreter  <!-- .element: class="fragment" -->
-   #!/bin/bash  <!-- .element: class="fragment" -->

---
### Variables
-   A temporary store for small pieces of information  <!-- .element: class="fragment" -->
-   No need to declare  <!-- .element: class="fragment" -->
-   Can contain any type of data - String, integer, float, etc  <!-- .element: class="fragment" -->
-   Good practice to surround with curly braces "{}"  <!-- .element: class="fragment" -->
-   Like file names, try and avoid spaces in variables where possible  <!-- .element: class="fragment" -->

+++
### Other types of variables
-   Special variables  <!-- .element: class="fragment" -->
-   Arrays (not covered today)  <!-- .element: class="fragment" -->

+++
### Special variables
-   $? - Exit code of last command  <!-- .element: class="fragment" -->
-   $0 - Script name  <!-- .element: class="fragment" -->
-   $1 - $N - Option 1 to whatever  <!-- .element: class="fragment" -->
-   $$ - PID of script  <!-- .element: class="fragment" -->
-   $IFS - Internal field separator - Normally set to whitespace  <!-- .element: class="fragment" -->

---
### User input
#### Syntax (read)

```ba(h
read <options> variable
``` 

+++
### Examples of p and s options 

  -p - Prompt 

```
read -p "Enter a number: " NUM
echo ${NUM}
```

  -s - Supress output

```
echo "Enter password: "
read -s PASSW
echo "${PASSW}"
```

Note:
The read command can be used to stop a script at certain points for debugging. I usually use the variable "dummyvar" so I know at a glance what the read is for.

+++
### A read example
```bash
echo "Enter your new password: "
read -s PASSWD1
echo "Enter your password again: "
read -s PASSWD2
if [[ ${PASSWD1} == ${PASSWD2} ]]
then
  PASSWD=$PASSWD
  echo "Your password has been saved"
else
  echo "The two passwords do not match, start over..."
fi
```
<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">Ask for password but supress output from user</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3-4">Ask user to repeat and supress</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5-6">if statement to make sure passwords match</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7-8">What to do if they match</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="9-10">What to do if they don't match</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="11">Close if statement</span>

---
### Conditional Handling
-  if statement  <!-- .element: class="fragment" -->

-  if else  <!-- .element: class="fragment" -->

-  if elif  <!-- .element: class="fragment" -->

-  case  <!-- .element: class="fragment" -->

+++
### if statement
*  Uses a test with a binary output to determine path to take
-  Test operators - http://tldp.org/LDP/Bash-Beginners-Guide/html/sect_07_01.html
-  Arithmetic operators - -eq, -ne, -lt, -le, -gt or -ge
+++
### if statement syntax
```bash
if [[ test condition ]]
then
  Do lots of stuff
fi
```
<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">The if statement and condition it is looking for</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">If the condition is true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Close out the if statement</span>

+++
### Example of use
```bash
grep Hello *
ANSW=$?
if [[ ${ANSW} -lt 1 ]]
then
  echo "The command worked"
fi
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1">The command you are testing output from</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2">Special variables can be very volitile so I usually create a "disposable" variable to hold them</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3-4">The if statement and condition it is looking for</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5">If the condition is true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="6">Close out the if statement</span>
+++
### if else statement
*  Uses a test with a binary output to determine path to take
*  Provides what to do if the condition is false
-  Syntax
```bash
if [[ test condition ]]
then
  Do lots of stuff
else
  Do different stuff
fi
```
<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">The if statement and condition it is looking for</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">If the condition is true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-5">If the statement is false, do this stuff</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="6">Close out the if statement</span>

+++
### Example of use
```bash
grep Hello *
ANSW=$?
if [[ ${ANSW} -lt 1 ]]
then
  echo "The command worked"
else
  echo "I can't find Hello anywhere"
fi
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">The command you are testing output from and "disposable" variable</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3-4">The if statement and condition it is looking for</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5">If the condition is true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="6-7">If the condition is NOT true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="8">Close out the if statement</span>

+++
### if elif statement
*  Uses a test with a binary output to determine path to take
*  Uses further tests to provide different paths
-  Syntax
```bash
if [[ test condition ]]
then
  Do lots of stuff
elif [[ Second test condition ]]
  Do different stuff
else
  Do different stuff
fi
```
<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">The if statement and condition it is looking for</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">If the condition is true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-5">If the first statement is false and this is true, do this stuff</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="6-7">If the first and second statements are false, do this stuff</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="8">Close out the if statement</span>

+++
### Example of use
```bash
ANSW=6
if [[ ${ANSW} -lt 1 ]]
then
  echo "The answer is less than 1"
elif [[ ${ANSW} -lt 5 ]]
  echo "The answer is less than 5"
else
  echo "The answer is less than 10" 
fi
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1">Setting a variable</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2-4">The if statement and condition it is looking for, and what to do if true</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5-6">The second statement and what to do if true</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7-8">If the first two conditions are NOT true, run this command</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="9">Close out the if statement</span>

+++
### case statement
*  Gives several different paths depending on the results of a single condition
```bash
case <expression> in
  case1)
    break
    ;;
  case2)
    break
    ;;
  *)
    break
    ;;
esac
```
<span class="code-presenting-annotation fragment current-only" data-code-focus="1">expression is usually a variable that has been previously set</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2-4">The first clause. "break" is needed to prevent endless case loop. ";;" terminates the clause</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5-7">The second clause. "break" is needed to prevent endless case loop. ";;" terminates the clause</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="8-10">The "catch all" clause. This happens if none of the other clauses match</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="11">Close your case statement</span>

Note:
Can replace (and better than) nested if statements

+++
### Example of use
```bash
disk=`df -h | grep -v snap | awk '{print $5}' | grep % | grep -v Use | sort -n | tail -1 | cut -d "%" -f1 -`
case ${disk} in
[1-6]*)
  echo="No disk issues here, move along"
  break
  ;;
[7-8]*)
  echo="There is a partition with ${disk}% space. Check it out..."
  break
  ;;
9[0-8])
  echo="Seriously...  One partition is ${disk}% full."
  break
  ;;
99)
  echo="Wake up and do something...There's a partition at ${disk}%!"
  break
  ;;
*)
  echo="W. T. F.!!!!"
  break
  ;;
esac
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1">Get a number</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2">Case statement</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3-6">Stanza 1</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7-10">Stanza 2</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="11-14">Stanza 3</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="15-18">Stanza 4</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="19-22">Stanza 5 - Catch all</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="23">Close case</span>

+++
### select case to create menus
*   Allows menus in your script

```bash
select <variable> in <list>
do
  case $<variable in
    case1)
      break
      ;;
    case2)
      break
      ;;
    *)
      break
      ;;
  esac
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">select statement with variable and list</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">The case statement using the select variable</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-6">The first clause. The result of menu number 1</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7-9">The second clause. The result of menu number 2</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="10-12">The "catch all" clause. This happens if the user picks a non choice</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="13">Close your case statement</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="14">Close your select statement</span>

+++
### Example
```bash
select NUM in $(cat file1) Exit
do
case ${NUM} in
  Exit)
    exit
    ;;
  *)
    echo $NUM
    ;;
esac
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">Will cat file 1 and use that for menu choices</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">case statement for value of '${NUM}'</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-6">Exit must come before * because it is defined</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7-9">Do whatever to '${NUM}'</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="10-11">Close case and select</span>

---
### Loops
- for loop  <!-- .element: class="fragment" -->
- while loop  <!-- .element: class="fragment" -->
- until loop  <!-- .element: class="fragment" -->

+++
### for
- Iterates through a list
- Syntax
```bash
for i in <list>
do
  All the things
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">for statement. i = variable. <list> can be any list you can think of</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">What to do with each item in the list</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Close loop</span>

+++
### for loop example
```
for i in {1..5}
do
  echo ${i}
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2">for statement. i = variable. List is the number range 1 to 5</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3">echo ${i} which is number 1 to 5</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Close loop</span>

+++
### while
-  Performs actions while a condition is true
```bash
while [[ condtion ]]
do
  Do stuff
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Close the while loop</span>

+++
### Example
```bash
x=0
while [[ ${x} -lt 10 ]]
do
  echo ${x}
  let x=${x}+1
  sleep 1
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1">Set variable x to 0</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2-3">Set condition that x cannot be 10 or more</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-6">Echo x, add 1 to x, sleep for 1 second</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7">Close loop</span>

+++
### until
-Performs actions until a condition is true
```bash
while [[ condtion ]]
do
  Do stuff
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-2"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="3"></span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Close the until loop</span>

+++
### Example
```bash
x=0
until [[ ${x} -ge 10 ]]
do
  echo ${x}
  let x=${x}+1
  sleep 1
done
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1">Set variable x to 0</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="2-3">Set condition that x must be 10 or more</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4-6">Echo x, add 1 to x, sleep for 1 second</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="7">Close loop</span>

---
### Functions
-   Functions are reusable bits of code
-   They cut down on file size by reducing repetition
-   Must be defined in a script before they are called
    -   Commonly all functions are defined at the very beginning of a script

+++
### Syntax
```bash
function <name> {
  Do all the things to $1
}

<name>
<name> foobar
```

<span class="code-presenting-annotation fragment current-only" data-code-focus="1-3">Defines the function</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="4">Calls the function</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="5">Calls the function and passes foobar as $1</span>

+++
### another use for Functions
-   Often times, if you have a series of commands you run often you can create a function file that gets called by .bashrc. This would be like alias command on steroids.

---
### Topics
-   Why script?  <!-- .element: class="fragment" -->
-   She-Bang
-   Variables  <!-- .element: class="fragment" -->
-   Special variables  <!-- .element: class="fragment" -->
-   User input  <!-- .element: class="fragment" -->

+++
### Topics (Cont)
-   Conditional handling  <!-- .element: class="fragment" -->
-   Select/case text menu  <!-- .element: class="fragment" -->
-   Loops  <!-- .element: class="fragment" -->
-   Functions  <!-- .element: class="fragment" -->

---
# Thanks.
## Remember the new venue next month
###  
###  
### Questions